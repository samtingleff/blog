<?php
# author: sam tingleff <sam@tingleff.com>
# disclaimer:
# I am no php programmer nor do I have any desire to be one...
# this is an ugly hack and I know it. I hacked this together
# as quickly as possible and haven't looked at it since.
# 
# change these ---
$mysql_host = "localhost";
$mysql_username = "sugarcrm";
$mysql_password = "sugarcrm";
$mysql_db = "sugarcrm";
$callme_link = "/click-to-call.php?phone=";
# end ---

$limit = 20;
$page = 1;
$q = null;
$fragment = false;
if (isset($_REQUEST['page'])) {
 $page = $_REQUEST['page'];
}
if (isset($_REQUEST['q'])) {
 $q = mysql_escape_string($_REQUEST['q']);
}
if (isset($_REQUEST['fragment'])) {
 $fragment = true;
}
$offset = ($page - 1) * $limit;
settype($page, 'integer');
settype($offset, 'integer');
$db = mysql_connect($mysql_host, $mysql_username, $mysql_password)
  or die("MySQL connection failed");
mysql_select_db($mysql_db)
  or die("SugarCRM database open failed");
$totalRowQuery = "select count(*) as num from contacts where ((first_name like '%$q%') or (last_name like '%$q%') or (title like '%$q%')) and (deleted = 0)";
$total_pages = mysql_fetch_array(mysql_query($totalRowQuery));
$total_pages = $total_pages['num'];
$prev = $page - 1;
$next = $page + 1;
$lastpage = ceil($total_pages/$limit);
$lpm1 = $lastpage - 1; //last page minus 1

$query = "select id, first_name, last_name, title, phone_home, phone_mobile, phone_work, phone_other from contacts where ((first_name like '%$q%') or (last_name like '%$q%') or (title like '%$q%')) and (deleted = 0) order by first_name, last_name limit $offset, $limit";
$result = mysql_query($query)
  or die("SugarCRMDB query failed");
$num_rows = mysql_num_rows($result);
$rows = array();
$i = 0;
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
  $rows[$i] = $row;
  ++$i;
}
mysql_close($db);
?>
<!-- include if not an ajax request -->
<? if (!$fragment) { ?>
<html>
 <head>
  <title>Phone dialer</title>
  <link href="sugar-browse-style.css" rel="stylesheet" type="text/css"/>
  <script type="text/javascript" src="js/YAHOO.js"></script>
  <script type="text/javascript" src="js/connection.js"></script>
  <script type="text/javascript" src="js/methods.js"></script>
 </head>
 <body>
  <div id="header">
   <form name="searchForm" action="sugar-browse.php" method="GET"">
    <p>
     <a href="javascript:getContent('content', 'sugar-browse.php?fragment=true')">all contacts</a>

     search: <input type="text" name="q" size="10" maxlength="20" onKeyUp="javascript:postForm('searchForm', 'content', 'sugar-browse.php?fragment=true')"/>
     <a href="javascript:postForm('searchForm', 'content', 'sugar-browse.php?fragment=true')">GO</a>
     <span id="statusarea"></span>
    </p>
   </form>
  </div>
  <script language="javascript">
   document.forms['searchForm'].elements['q'].focus();
  </script>


  <div id="content">
<? } ?><!-- below is ajax page fragment -->
   <div class="pagination">
    <p>Showing page <? echo "$page of $lastpage"; ?></p>
    <p>
     <? if ($page > 1) { ?>
      <a href="javascript:getContent('content', 'sugar-browse.php?fragment=true&q=<? echo $q ?>')">first</a>
      <a href="javascript:getContent('content', 'sugar-browse.php?fragment=true&q=<? echo $q ?>&page=<? echo $prev ?>')">prev</a>
     <? } ?>
     <? if ($page < $lastpage) { ?>
      <a href="javascript:getContent('content', 'sugar-browse.php?fragment=true&q=<? echo $q ?>&page=<? echo $next ?>')">next</a>
      <a href="javascript:getContent('content', 'sugar-browse.php?fragment=true&q=<? echo $q ?>&page=<? echo $lastpage?>')">last</a>
     <? } ?>
    </p>
   </div>
  <table id="contacts_table">
   <tr>
    <th>name</th>
    <th>title</th>
    <th>home</th>
    <th>office</th>
    <th>mobile</th>
    <th>other</th>
   </tr>
<?
for ($i = 0; $i < count($rows); ++$i) {
?>
   <tr>
    <td width="15%"><a href="/sugar/index.php?action=DetailView&module=Contacts&record=<? echo $rows[$i]{'id'}; ?>"><? echo $rows[$i]{'first_name'} . " " . $rows[$i]{'last_name'} ?></a></td>
    <td width="20%"><? echo $rows[$i]{'title'} ?></td>
    <td width="20%"><a href="<? echo $callme_link ?><? echo ereg_replace("[^0-9]", "", $rows[$i]{'phone_home'}) ?>"><? echo $rows[$i]{'phone_home'} ?></a></td>
    <td width="15%"><a href="<? echo $callme_link ?><? echo ereg_replace("[^0-9]", "", $rows[$i]{'phone_work'}) ?>"><? echo $rows[$i]{'phone_work'} ?></a></td>
    <td width="15%"><a href="<? echo $callme_link ?><? echo ereg_replace("[^0-9]", "", $rows[$i]{'phone_mobile'}) ?>"><? echo $rows[$i]{'phone_mobile'} ?></a></td>
    <td width="15%"><a href="<? echo $callme_link ?><? echo ereg_replace("[^0-9]", "", $rows[$i]{'phone_other'}) ?>"><? echo $rows[$i]{'phone_other'} ?></a></td>
   </tr>
<?
}
?>
  </table>
<? if (!$fragment) { ?>
  </div>
 </body>
</html>
<? } ?>
