function responseSuccessFunction(o)
{
	document.getElementById('statusarea').innerHTML = "";
	document.getElementById(this.id).innerHTML = o.responseText;
}
function responseFailureFunction(o)
{
	document.getElementById('statusarea').innerHTML = o.statusText;
	document.getElementById(this.id).innerHTML = "<ul class=\"errors\"><li>Error: " + o.statusText + "</li></ul>";
}
function getContent(id, url)
{
	var callback = new Object();
	callback.success = responseSuccessFunction;
	callback.failure = responseFailureFunction;
	callback.id = id;
	oldContent = document.getElementById(id).innerHTML;
	document.getElementById('statusarea').innerHTML = "<img src='js/spinner.gif'/> searching...";
	var cobj = YAHOO.util.Connect.asyncRequest('GET',url,callback,null);
}
function postForm(formName, id, url)
{
	YAHOO.util.Connect.setForm(formName);
	var callback = new Object();
	callback.success = responseSuccessFunction;
	callback.failure = responseFailureFunction;
	callback.id = id;
	document.getElementById('statusarea').innerHTML = "<img src='js/spinner.gif'/> searching...";
	var cObj = YAHOO.util.Connect.asyncRequest('POST', url, callback);
}
function validateThenPostForm(formName, validateFunction, form, id, url)
{
	var isValid = validateFunction(form);
	if (isValid) {
		postForm(formName, id, url);
	}
	return (false);
}
